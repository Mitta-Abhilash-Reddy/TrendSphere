package cn.tech.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import cn.tech.Dao.PostDao;
import cn.tech.model.User;

/**
 * Servlet implementation class DeletePostServlet
 */
@WebServlet("/DeletePostServlet")
public class DeletePostServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User loggedInUser = (User) session.getAttribute("user");

        if (loggedInUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int postId = Integer.parseInt(request.getParameter("postId"));
        PostDao postDao = new PostDao();

        boolean isDeleted = postDao.deletePost(postId, loggedInUser.getId());

        if (isDeleted) {
            response.sendRedirect("profile.jsp?msg=Post deleted successfully");
        } else {
            response.sendRedirect("profile.jsp?error=Failed to delete post");
        }
    }
}
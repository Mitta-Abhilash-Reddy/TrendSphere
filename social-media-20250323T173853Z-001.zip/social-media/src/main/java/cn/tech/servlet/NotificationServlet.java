package cn.tech.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.StringJoiner;

import cn.tech.Dao.NotificationDao;
import cn.tech.model.Notification;
import cn.tech.model.User;

/**
 * Servlet implementation class NotificationServlet
 */
@WebServlet("/NotificationServlet")
public class NotificationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private NotificationDao notificationDao;

    public void init() {
        notificationDao = new NotificationDao();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User loggedInUser = (User) request.getSession().getAttribute("user");

        if (loggedInUser == null) {
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("[]");
            return;
        }

        List<Notification> notifications = notificationDao.getUnreadNotifications(loggedInUser.getId());

        StringJoiner json = new StringJoiner(",", "[", "]");
        for (Notification n : notifications) {
            json.add("{"
                + "\"id\":" + n.getId() + ","
                + "\"type\":\"" + n.getType() + "\","
                + "\"postId\":" + n.getPostId() + ","
                + "\"isRead\":" + n.isRead() + ","
                + "\"message\":\"" + n.getType() + " on your post\""  // Add message dynamically
                + "}");
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json.toString());
    }

}
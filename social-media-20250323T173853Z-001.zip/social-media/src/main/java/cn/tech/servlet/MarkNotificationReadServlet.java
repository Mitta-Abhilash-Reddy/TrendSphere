package cn.tech.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import cn.tech.Dao.NotificationDao;

/**
 * Servlet implementation class MarkNotificationReadServlet
 */
@WebServlet("/MarkNotificationReadServlet")
public class MarkNotificationReadServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String notificationIdParam = request.getParameter("notificationId");
	    if (notificationIdParam != null && !notificationIdParam.isEmpty()) {
	        try {
	            int notificationId = Integer.parseInt(notificationIdParam);
	            NotificationDao notificationDao = null;
				notificationDao.markNotificationsAsRead(notificationId);
	            response.getWriter().write("success");
	        } catch (NumberFormatException e) {
	            response.getWriter().write("error");
	        }
	    } else {
	        response.getWriter().write("error");
	    }
	}

}




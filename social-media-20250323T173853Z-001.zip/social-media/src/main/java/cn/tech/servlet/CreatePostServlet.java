package cn.tech.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;

import cn.tech.Dao.PostDao;
import cn.tech.model.Post;
import cn.tech.model.User;

/**
 * Servlet implementation class CreatePostServlet
 */
@WebServlet("/CreatePostServlet")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,    // 1 MB
    maxFileSize = 1024 * 1024 * 10,     // 10 MB
    maxRequestSize = 1024 * 1024 * 15    // 15 MB
)
public class CreatePostServlet extends HttpServlet {
    private static final String UPLOAD_DIR = "post-images";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Get the user from session
        User loggedInUser = (User) request.getSession().getAttribute("user");
        if (loggedInUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String content = request.getParameter("content");
        Part imagePart = request.getPart("image");
        String imagePath = null;

        // Create the upload directory if it doesn't exist
        String applicationPath = request.getServletContext().getRealPath("");
        String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;
        File uploadDir = new File(uploadFilePath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        // Process image if uploaded
        if (imagePart != null && imagePart.getSize() > 0) {
            String fileName = System.currentTimeMillis() + 
                            getFileExtension(imagePart.getSubmittedFileName());
            imagePath = fileName;
            
            // Save the file
            imagePart.write(uploadFilePath + File.separator + fileName);
        }

        // Create and save the post
        Post post = new Post();
        post.setUserId(loggedInUser.getId());
        post.setContent(content);
        post.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        post.setImagePath(imagePath);

        PostDao postDao = new PostDao();
        boolean success = postDao.createPost(post);

        if (success) {
            response.sendRedirect("index.jsp");
        } else {
            // If post creation fails, delete the uploaded file
            if (imagePath != null) {
                File uploadedFile = new File(uploadFilePath + File.separator + imagePath);
                if (uploadedFile.exists()) {
                    uploadedFile.delete();
                }
            }
            request.setAttribute("error", "Failed to create post");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }

    private String getFileExtension(String fileName) {
        if (fileName == null) return "";
        int lastDot = fileName.lastIndexOf('.');
        if (lastDot == -1) return "";
        return fileName.substring(lastDot);
    }
}

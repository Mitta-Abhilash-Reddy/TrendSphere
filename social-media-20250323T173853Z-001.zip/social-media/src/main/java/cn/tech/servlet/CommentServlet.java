package cn.tech.servlet;

import cn.tech.Dao.CommentDao;
import cn.tech.connection.DBCon;
import cn.tech.model.Comment;
import cn.tech.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

@WebServlet("/CommentServlet")
public class CommentServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 HttpSession session = request.getSession();
	        User user = (User) session.getAttribute("user");

	        if (user == null) {
	            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
	            return;
	        }

	        int postId = Integer.parseInt(request.getParameter("postId"));
	        String commentText = request.getParameter("comment");

	        Comment comment = new Comment();
	        comment.setUserId(user.getId());
	        comment.setPostId(postId);
	        comment.setContent(commentText);

	        CommentDao commentDao = new CommentDao();
	        boolean success = commentDao.saveComment(comment);

	        response.setContentType("text/plain");
	        PrintWriter out = response.getWriter();
	        out.print(success ? "Success" : "Error");    }
}

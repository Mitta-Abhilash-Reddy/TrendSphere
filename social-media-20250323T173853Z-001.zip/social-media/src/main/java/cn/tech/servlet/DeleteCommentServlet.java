package cn.tech.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import cn.tech.Dao.CommentDao;
import cn.tech.model.User;

/**
 * Servlet implementation class DeleteCommentServlet
 */
@WebServlet("/DeleteCommentServlet")
public class DeleteCommentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User loggedInUser = (User) session.getAttribute("user");

        if (loggedInUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int commentId = Integer.parseInt(request.getParameter("commentId"));
        CommentDao commentDao = new CommentDao();

        boolean isDeleted = commentDao.deleteComment(commentId, loggedInUser.getId());

        if (isDeleted) {
            response.sendRedirect("profile.jsp?msg=Comment deleted successfully");
        } else {
            response.sendRedirect("profile.jsp?error=Failed to delete comment");
        }
    }
}

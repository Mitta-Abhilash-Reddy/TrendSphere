package cn.tech.model;

import java.sql.Timestamp;

public class Notification {
    private int id;
    private int userId;
    private String type;
    private Integer postId;
    private boolean isRead;
    private Timestamp createdAt;

    public Notification(int id, int userId, String type, Integer postId, boolean isRead, Timestamp createdAt) {
        this.id = id;
        this.userId = userId;
        this.type = type;
        this.postId = postId;
        this.isRead = isRead;
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public String getType() {
        return type;
    }

    public Integer getPostId() {
        return postId;
    }

    public boolean isRead() {
        return isRead;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setRead(boolean isRead) {
        this.isRead = isRead;
    }
}
